const Discord = require('discord.js');
const client = new Discord.Client();
const quiz = require("./quiz.json");
const { token } = require('./config.json');

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})


client.on('message', msg => {
    if(msg.author.bot) return;
    if(msg.author.id === client.user.id) return;

    if(msg.content === "!퀴즈"){

        const item = quiz[Math.floor(Math.random() * quiz.length)];
        const limit = 5;
        const filter = (response) => {
            return item.answer.some((answer) => answer === response.content);
        }   
        
        msg.channel.send(`${item.question} (제한시간: ${limit}초)`)
        .then(() => {
            msg.channel.awaitMessages(filter, {max: 1,time: limit * 1000})
            .then((collected) => {
                msg.channel.send(`${collected.first().author} 정답!!`);
            })
            .catch((err) => {
                msg.channel.send("제한시간이 지났습니다!");
            })
        }) 

    }
});

client.login(token);