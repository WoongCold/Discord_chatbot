const { Client, Intents } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const { token } = require('./config.json');

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})

const convertEmotion = (who) =>{
    if(who == "가위"){
        return "👉";
    }
    else if(who === "바위") {
        return "✊";
    }
    else if(who === "보"){
        return "🖐️";
    }
}

client.on('message', msg => {
    // 입력한 값이 가위, 바위, 보 일때
    if(msg.content === "가위" || msg.content === "바위" || msg.content == "보") {
        const human = msg.content; // 사람이 입력한 값을 human이라는 상수에 대입
        const list = ["가위","바위","보"]; // 봇은 가위, 바위, 보 중에서 냄
        const random = Math.floor(Math.random() * 3); // 0 ~ 2 사이의 랜덤한 숫자
        
        const bot = list[random];// 가위, 바위, 보 중 랜덤한 하나를 bot에 대입

        let winner = ""; // 승자가 들어갈 변수(let : 변수, const : 바꿀 수 없는 상수)

        // 만약 사람이 낸거랑, 봇이 낸거랑 같다면
        if(human === bot){
          winner = "비김";  
        }
        else{ //비기지 않았다면???
            human === "가위" ? (winner = bot === "바위" ? "봇" : "인간") : "";
            //사람이 가위를 냈는데, 봇이 바위를 냈다면???? 봇이 이긴거고. 나머지를 냈으면 인간이 이김!!!
            human === "바위" ? (winner = bot === "보" ? "봇" : "인간") : "";
            human === "보" ? (winner = bot === "가위" ? "봇" : "인간") : "";
            // 승자를 winner라는 변수에 넣어주는 로직!!!!
        }
        // 결과
        const result = 
`
사람 : ${convertEmotion(human)} vs 봇 : ${convertEmotion(bot)}
${winner === "비김" ? "우리는 비겼다 닌겐." : "큭크...큭크크 " + winner + "의 승리다"}
`//만약 winner에 들어있는 값이 비김이면 비겼다라고 출력. 비기지 않았다면 winner(봇 또는 사람의 승리)
            
        msg.reply(result);
    }

});

client.login(token);