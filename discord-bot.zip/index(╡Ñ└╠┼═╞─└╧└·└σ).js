const { Client, Intents } = require('discord.js');
const fs = require('fs');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const { token } = require('./config.json');

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})


client.on('message', msg => {
    if(msg.author.bot) return;
    if(msg.author.id === client.user.id) return;

    const id = msg.author.id;
    const name = msg.author.username;
    
    const filePath = `./data/${id}.json`;
    !fs.existsSync(filePath) ? fs.writeFileSync(filePath, JSON.stringify({})) : null;

    const user = JSON.parse(fs.readFileSync(filePath, "utf-8"));
    
    const today = new Date();
    const date = "" + today.getFullYear() + today.getMonth() + today.getDate();

    const howMuch  = 5000;
    
    if(msg.content === "얼쑤머니 줘"){
        let saveUser = {};
        if(user.id){
            if(user.date === date){
                msg.reply(`오늘은 이미 받았다.`);
                saveUser = user;
            }
            else{
                msg.reply(`${howMuch}원이 지급되었다!\n${name}의 현재 잔액은 ${user.money} -> ${user.money + howMuch}이야!`)
                saveUser = {
                    id: id,
                    name: name,
                    date: date,
                    money: user.money + howMuch
                }
            }
        } 
        else{
            msg.reply(`${name}!! 시작하는걸 환영해! ${howMuch}원이 지급됐어!`);
            saveUser = {id, name, date, money : howMuch};
        }

        fs.writeFileSync(filePath, JSON.stringify(saveUser));
    } 
    if(msg.content === "얼쑤머니 잔액"){
        user.id ? msg.reply(`${user.name}의 잔액은 ${user.money}이야!`) : msg.reply(`등록되지 않은 유저입니다.`)
    }

});

client.login(token);