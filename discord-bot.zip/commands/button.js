const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('버튼')
		.setDescription('버튼을 만듭니다.'),
	async execute(interaction) {
        const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('test1')
					.setLabel('첫번째') 
					.setStyle('PRIMARY'),
                new MessageButton()
                    .setCustomId('test2')
                    .setLabel('두번째') 
                    .setStyle('SECONDARY'),
        );            
        await interaction.reply({ content: '버튼!', components: [row] })
        
        const filter = (interaction) => {
            return interaction.customId === "test1" || "test2";
        };
        const colletor = interaction.channel.createMessageComponentCollector({
            // 몇초동안 반응할 수 있는지
            time: 60 * 1000,
            filter     
        });

        colletor.on("collect", async(interaction) => {
            // 버튼을 클릭했을 때 test1이면 무엇을 할지 기능을 만들어줌
            if(interaction.customId === "test1"){
                await interaction.reply("test1 버튼을 클릭했다.");
            }
            else if(interaction.customId === "test2"){
                // 버튼이 사라짐
                await interaction.update({
                    content: "버튼이 클릭됐어!",
                    components: []
                })
            }
        });
        // 버튼의 시간초과가 됐을시 무엇을 할지
        colletor.on("end", async(collect) => {
            console.log("시간초과");
        })
	},
};