const axios = require("axios");
const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('test2')
		.setDescription('Replies with test2!'),
	async execute(interaction) {
        const bitcoinResult = await axios.get('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false', {
            headers: {
              'X-CMC_PRO_API_KEY': 'b54bcf4d-1bca-4e8e-9a24-22ff2c3d462c',
            }}); 

        let period = "";

        for(let i=0; i<20; i++){
            period += `$${bitcoinResult.data[i].id} `
        }

        const price = {
            "content": "10일간의 비트코인 가격 변동",
            "embeds": [{
                "author": {
                    "name": "찬웅봇의 왼팔 - 비트코인 알리미",
                    "url": "https://www.coindesk.com/price/bitcoin",
                    "icon_url": "https://en.bitcoin.it/w/images/en/2/29/BC_Logo_.png"   
                },
                //"title": "현재 비트코인 가격 : " + bitcoinResult.data.bpi.USD.rate + "$",
                
                "title": "10일간의 비트코인 가격 : " + period
                //"description": 
            }]
        }

        const discordUrl = "https://discord.com/api/webhooks/964066152114454568/yr_8wcnsJhEYY_iSpc8XMMGBfA6OAPribJd4xTr-nu_9Ks8Hxl3XaaJPhgTV84jphiqj"
        const result = await axios.post(discordUrl, price)

		await interaction.reply(result);
	}
};