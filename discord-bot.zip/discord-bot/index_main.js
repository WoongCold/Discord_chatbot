const { Client, Intents } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const fs = require('fs');
const { token } = require('./config.json');
const jsonData_ohm= require('./ohm.json');
const jsonData_high= require('./df_high.json');
const jsonData_low= require('./df_low.json');

let data_ohm = JSON.parse(JSON.stringify(jsonData_ohm));
let data_high = JSON.parse(JSON.stringify(jsonData_high));
let data_low = JSON.parse(JSON.stringify(jsonData_low));

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})

client.on('message', msg => {
    if(msg.content.substring(0,3) === "!잔액"){
        const address = msg.content.substring(4);

        for(let i = 0; i<data_ohm.length; i++){
            if(address === data_ohm[i]["address"]){
                const result = `total_token: ${data_ohm[i]["total"]}개 -> usd_value: $${data_ohm[i]["usd_value"]}`;
                msg.reply(result);
            }
        }
    }
    if(msg.content.substring(0,5) === "!활동내역"){
        const address = msg.content.substring(6);
        let result = "";
        for(let i = 0; i<data_high.length; i++){
            if(address === data_high[i]["wallet_address"]){
                result += `time: ${data_high[i]["time"]}, ohm_price: ${data_high[i]["ohm_price"]}, event: ${data_high[i]["event"]}, amount: ${data_high[i]["amount"]}, value: ${data_high[i]["value"]} \n`;     
            }
        }
        msg.reply(result);
    }

});

client.login(token);