const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageSelectMenu } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('셀렉트메뉴')
		.setDescription('셀렉트메뉴를 호출합니다.'),
	async execute(interaction) {
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId("select")
                    .setPlaceholder("선택되지 않음")
                    //.setMinValues(1) // 멀티셀렉트 기능
                    //.setMaxValues(3)
                    .setOptions([
                        {
                            label: "셀렉트1",
                            description: "설명1",
                            value: "select1"
                        },
                        {
                            label: "셀렉트2",
                            description: "설명2",
                            value: "select2"
                        }, 
                        {
                            label: "셀렉트3",
                            description: "설명3",
                            value: "select3"
                        },
                        {
                            label: "셀렉트4",
                            description: "설명4",
                            value: "select4"
                        },
                    ])
            )

		await interaction.reply({ content: "셀렉트 메뉴 호출", components: [row] });
        
        // 셀렉트 메뉴 클릭시 반응            
        const filter = (interaction) => {
            return interaction.customId === "select";
        };        

        const colletor = interaction.channel.createMessageComponentCollector({
            // 몇초동안 반응할 수 있는지
            time: 60 * 1000,
            filter     
        });

        colletor.on("collect", async(interaction) => {
            if(interaction.customId === "select"){
                let selected = "";

                interaction.values.map((value) => {
                    switch(value) {
                        case "select1":
                            selected += "1번 "
                            break;
                        case "select2":
                            selected += "2번 "
                            break;
                        case "select3":
                            selected += "3번 "
                            break;
                        case "select4":
                            selected += "4번 "
                            break;
                    }
                })

                
                interaction.reply(selected + "선택됨")
            }
            
        });
        colletor.on("end", async (collect) => {
            console.log("시간초과!");
        })

	},
};