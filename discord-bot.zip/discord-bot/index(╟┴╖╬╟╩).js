// const { Client, Intents, MessageEmbed, DiscordAPIError } = require('discord.js');
// const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const Discord = require('discord.js');
const client = new Discord.Client();
const { token } = require('./config.json');

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})


client.on('message', msg => {
    if(msg.content === "프로필"){
        const embed = new Discord.MessageEmbed()
        .setAuthor("얼쑤봇","https://avatars.githubusercontent.com/u/96611098?v=4")
        .setTitle("얼쑤봇 프로필")
        .setURL("https://github.com/WoongCold")
        .setColor("#4374D9")
        .setDescription("안녕하세요~")
        .setThumbnail("https://avatars.githubusercontent.com/u/96611098?v=4")
        .addFields(
            {name: "취미", value: "대답하기", inline:true},
            {name: "특기", value: "로봇", inline:true}
        )
        .setImage("https://avatars.githubusercontent.com/u/96611098?v=4")
        .setTimestamp(new Date().setDate(5))
        .setFooter("맨 마지막으로 들어갈 말","https://avatars.githubusercontent.com/u/96611098?v=4")

        msg.channel.send(embed)
    }

});

client.login(token);