const Discord = require('discord.js');
const client = new Discord.Client();
const { token } = require('./config.json');

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
})


client.on('message', msg => {
    if(msg.author.bot) return;
    if(msg.author.id === client.user.id) return;

    if(msg.content.substring(0,3) == "!투표"){
        const description = msg.content.substring(3);
        const embed = new Discord.MessageEmbed()
        .setTitle("👇투표합시다!👇")
        .setDescription(description)
        .setColor("#4374D9");
    
        msg.channel.send(embed)
        .then((vote) => {
            vote.react("👍")
            vote.react("👎")
        })
    }

});

client.login(token);